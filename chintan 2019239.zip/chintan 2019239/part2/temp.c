#include <stdio.h> 
#include <time.h>        
#include <string.h>
#include <fcntl.h> 
#include <stdlib.h>
int main(void) {
    
    printf("%s",getenv("HOME"));

    return 0;
}