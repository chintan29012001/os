#include <stdio.h>

int main(int argc, char const *argv[])
{
    /* code */
    int a=0;
    int b=1;
    printf("a: %d  b: %d \n",a,b);//printing variables
    return 0;
}
